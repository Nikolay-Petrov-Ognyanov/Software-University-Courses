const { getAllByDate, getRecent } = require("../services/bookService")

const homeController = require("express").Router()

homeController.get("/", async (req, res) => {
    res.render("home", {
        title: "Home Page",
        //search: req.query.search
    })
})

module.exports = homeController